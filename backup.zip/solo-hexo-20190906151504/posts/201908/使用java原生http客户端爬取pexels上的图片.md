title: 使用java原生http客户端爬取pexels上的图片
date: '2019-08-30 15:10:52'
updated: '2019-08-30 15:10:52'
tags: [爬虫]
permalink: /articles/2019/08/30/1567149052572.html
---
# 准备工作
pexels上面有很多图片，突然想把上面的图片爬下来，把图片URL更新到数据库中，然后再从数据库中把图片的内容下载到云对象存储中。
	首先从pexels网站上面找可以爬取的url，经过查找，一共找到三个url可以爬取
    https://www.pexels.com/new-photos/?format=js&page=1&type=
    https://www.pexels.com/popular-photos/all-time/?format=js&page=1&type=
    https://www.pexels.com/?format=js&seed=&type=
这三个url都可以爬到数据，其中，前两个是根据page分页的，也可以添加seed参数，seed是UTC时间戳，经过URL编码后拼接到后面，第三个只有根据seed分页查询，这三个请求返回的数据差不多一样，只有第一行的分页参数不同。
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019083014513410.png)
这是第前两个url返回的数据格式
![这是第三个url返回的数据](https://img-blog.csdnimg.cn/20190830145418376.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3NpbmF0XzM5MjkxMzY3,size_16,color_FFFFFF,t_70)
# 爬取
爬取分为5步走：

 - 构建请求url
 - 发送请求
 - 解析返回数据
 - 图片去重
 - 封装为实体
 - 持久化到数据库
其中因为响应返回的其实是js数据，所以就使用正则匹配下一页，跟每一项中的url,还有描述。
图片去重根据图片url有一串数字，可以根据这个去重
结果如下：
![数据库中的数据](https://img-blog.csdnimg.cn/20190830150028359.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3NpbmF0XzM5MjkxMzY3,size_16,color_FFFFFF,t_70)
主要代码如下：

```
 private final static String URL = "https://www.pexels.com/popular-photos/all-time/?format=js";
    protected static final Pattern NEXT_SEED = Pattern.compile("next_page.+Next");
    protected static final Pattern NUMBER_PATTERN = Pattern.compile("\\d+");
    protected static final Pattern ITEM_PATTERN = Pattern.compile("data-photo-modal-image-alt.+?data-photo-modal-image-download-link=\\\\'.+?'");

    @Override
    public ParseBO request(String seed) {
        String url = StringUtils.isEmpty(seed) ? URL + "&type=": URL + "&page=" + seed + "&type=";
        HttpRequests requests = HttpRequests.getInstance(url)
                .addHead("cache-control","no-cache")
                .addHead("user-agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36")
                .addHead("x-requested-with","XMLHttpRequest");
        int i = 0;
        HttpBO bo = null;
        while (i > RETRY_COUNT || bo == null || bo.getResponseCode() != 200){
            try {
                bo = requests.doGet();
            }catch (Exception e){
                e.printStackTrace();
            }
            i++;
        }
        ParseBO parseBO = parse(bo.getResponseText());
        return parseBO;
    }
```
# 转存数据到云对象存储
对象存储使用有免费额度的云厂商，我用的是ufile。有20G免费空间，但是还是不够用，目前我爬到了将近40000条图片url，有的图片有20M大。
然后从数据库取url，起5个线程同时下载，
![转存后的图片](https://img-blog.csdnimg.cn/20190830150615646.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3NpbmF0XzM5MjkxMzY3,size_16,color_FFFFFF,t_70)
转存比较慢
将转存后的url也更新到数据库里面，就完成了。
